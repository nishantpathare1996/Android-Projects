package com.example.stockwatch;

import java.io.Serializable;

public class Stock implements Serializable {
    private String stockSymbol;
    private String companyName;
    private double price;
    private double priceChange;
    private double changePercentage;
    private int COLOR_CODE;

    public Stock(String stockSymbol, String companyName)
    {
        this.stockSymbol = stockSymbol;
        this.companyName = companyName;
        this.price = 0;
        this.priceChange = 0;
        this.changePercentage = 0;
        this.COLOR_CODE = decideColorCode();
    }

    public Stock(String stockSymbol, String companyName, double price, double priceChange, double changePercentage) {
        this.stockSymbol = stockSymbol;
        this.companyName = companyName;
        this.price = price;
        this.priceChange = priceChange;
        this.changePercentage = changePercentage;
        this.COLOR_CODE = decideColorCode();
    }

    public String getStockSymbol() {
        return stockSymbol;
    }

    public void setStockSymbol(String stockSymbol) {
        this.stockSymbol = stockSymbol;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getPriceChange() {
        return priceChange;
    }

    public void setPriceChange(double priceChange) {
        this.priceChange = priceChange;
    }

    public double getChangePercentage() {
        return changePercentage;
    }

    public void setChangePercentage(double changePercentage) {
        this.changePercentage = changePercentage;
    }

    public int getCOLOR_CODE() {
        return COLOR_CODE;
    }

    public int decideColorCode()
    {
        if (priceChange > 0)
            return 1;
        else if (priceChange < 0)
            return 2;
        else
            return 3;
    }
}
