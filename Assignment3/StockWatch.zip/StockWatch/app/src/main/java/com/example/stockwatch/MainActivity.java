package com.example.stockwatch;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Objects;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, View.OnLongClickListener {

        private ArrayList<Stock> stockList;  // Main content is here
        private RecyclerView recyclerstocks; // Layout's recyclerview
        private SwipeRefreshLayout swiper; // The SwipeRefreshLayout
        private StockAdapter mAdapter; // Data to recyclerview adapter
        private static final String TAG = "MainActivity";
        private String search;
        private DatabaseHandler databaseHandler;
        private HashMap<String,String> hashMap;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
            recyclerstocks = findViewById(R.id.recyclerstocks);
            swiper = findViewById(R.id.swiper);
            hashMap = new HashMap<String, String>();
            stockList = new ArrayList<>();

            swiper.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
                @Override
                public void onRefresh() {
                    doRefresh();
                }
            });

            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) {
                Toast.makeText(this, "Cannot access ConnectivityManager", Toast.LENGTH_SHORT).show();
                return;
            }
            NetworkInfo netInfo = cm.getActiveNetworkInfo();

            if (netInfo != null && netInfo.isConnected()) {
                NameRunnable nameRunnable = new NameRunnable(this);
                new Thread(nameRunnable).start();
                //getStockData();
            }
            else {
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("No Network Connection");
                builder.setMessage("Stocks cannot Be Updated Without a Network Connection");
                AlertDialog dialog = builder.create();
                dialog.show();
            }
            databaseHandler = new DatabaseHandler(this);
            mAdapter = new StockAdapter(stockList, this);
            recyclerstocks.setAdapter(mAdapter);
        recyclerstocks.setLayoutManager(new LinearLayoutManager (this));
    }

    private void doRefresh() {

        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) {
            Toast.makeText(this, "Cannot access ConnectivityManager", Toast.LENGTH_SHORT).show();
            return;
        }
        NetworkInfo netInfo = cm.getActiveNetworkInfo();

        if (netInfo != null && netInfo.isConnected()) {
            getStockData();
            NameRunnable nameRunnable = new NameRunnable(this);
            new Thread(nameRunnable).start();


        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("No Network Connection");
            builder.setMessage("Stocks cannot Be Updated Without a Network Connection");
            AlertDialog dialog = builder.create();
            dialog.show();
            swiper.setRefreshing(false);
        }
        Toast.makeText(MainActivity.this, "Refreshed", Toast.LENGTH_SHORT).show();
    }

    public ArrayList<Stock> getStocksArrayList()
    {
        return stockList;
    }

    public void getStockData()
    {
        StockRunnable stockRunnable = new StockRunnable(this);
        new Thread(stockRunnable).start();
       // swiper.setRefreshing(false);
    }

    public void updateData(final HashMap<String,String> stockMap) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                hashMap.putAll(stockMap);
            }
        });

    }

    public void updateStockData(final ArrayList<Stock> tempList)
    {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                stockList.clear();
                stockList.addAll(sortStocks(tempList));
                mAdapter.notifyDataSetChanged();
                swiper.setRefreshing(false);
            }
        });

    }

    ArrayList<Stock> sortStocks(ArrayList<Stock> stock)
    {
        Collections.sort(stock, new Comparator<Stock>() {
            @Override
            public int compare(Stock s1, Stock s2) {
                return s1.getStockSymbol().compareTo(s2.getStockSymbol());
            }
        });
        return stock;
    }

    public void stockFind(String string){
        ArrayList<Stock> tempList = new ArrayList<>();
        for(String key : hashMap.keySet()){
            if(key.startsWith(string) || Objects.requireNonNull(hashMap.get(key)).contains(string))
            {
                Stock stock = new Stock(key,hashMap.get(key));
                tempList.add(stock);
            }
        }
        Log.d(TAG, "updateData: bp: "+tempList.size() +" Stocks found");
        if(tempList.size() > 1)
        {
            manyStock(tempList);
        }
        else if (tempList.size() == 1)
        {
            if(checkDuplicateStock(tempList.get(0)))
                saveDB(tempList.get(0));
        }
        else
        {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Symbol Not Found: " + string);
            builder.setMessage("No such Stock Found");
            AlertDialog dialog = builder.create();
            dialog.show();
            Log.d(TAG, "searchStock: bp: No Stock Found");
        }
    }

    public void manyStock(final ArrayList<Stock> tempList)
    {
        final CharSequence[] sArray = new CharSequence[tempList.size()];
        for (int i = 0; i < tempList.size(); i++)
            sArray[i] = tempList.get(i).getStockSymbol() + " | " + tempList.get(i).getCompanyName().toLowerCase();

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Make a selection");

        builder.setItems(sArray, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which)
            {
                Stock temp  = tempList.get(which);
                Log.d(TAG, "onClick: bp: sArray["+which+"]: "+sArray[which]);
                Log.d(TAG, "onClick: bp: temp: "+temp);
                if(checkDuplicateStock(temp))
                    saveDB(temp);
            }
        });

        builder.setNegativeButton("NEVERMIND", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                Toast.makeText(MainActivity.this, "You changed your mind!", Toast.LENGTH_SHORT).show();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    public boolean checkDuplicateStock(Stock s)
    {
        for (Stock temp: stockList)
        {
            if(temp.getStockSymbol().equals(s.getStockSymbol()))
            {
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);

                //builder.setIcon(R.drawable.ic_duplicate);
                builder.setTitle("Duplicate Stock");
                builder.setMessage("Stock Symbol "+ s.getStockSymbol() + " is already displayed");
                AlertDialog dialog = builder.create();

                dialog.show();
                return false;
            }
        }
        return true;
    }

    public void saveDB(Stock s)
    {
        databaseHandler.addStock(s);
        stockList.add(s);
        stockList = sortStocks(stockList);
        getStockData();
        mAdapter.notifyDataSetChanged();
        Log.d(TAG, "saveDB: bp: Saved " + s.getStockSymbol() + " to dB.");
    }

    @Override
    protected void onResume()
    {
        ArrayList<Stock> tempList = databaseHandler.loadStocks();
        stockList.clear();
        stockList.addAll(sortStocks(tempList));
        mAdapter.notifyDataSetChanged();

        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) {
            Toast.makeText(this, "Cannot access ConnectivityManager", Toast.LENGTH_SHORT).show();
            return;
        }
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        if (netInfo != null && netInfo.isConnected()) {
            synchronized (this){
                getStockData();
            }
        }else {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("No Network Connection");
            builder.setMessage("Stocks cannot Be Updated Without a Network Connection");
            AlertDialog dialog = builder.create();
            dialog.show();
        }
        super.onResume();
    }

    @Override
    protected void onDestroy()
    {
        databaseHandler.shutDown();
        super.onDestroy();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main_menu, menu);
        return true;
    }


    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.addstock:
                ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                if (cm == null) {
                    Toast.makeText(this, "Cannot access ConnectivityManager", Toast.LENGTH_SHORT).show();
                    return false;
                }

                NetworkInfo netInfo = cm.getActiveNetworkInfo();

                if (netInfo != null && netInfo.isConnected()) {
                    synchronized (this){
                        NameRunnable nameRunnable = new NameRunnable(this);
                        new Thread(nameRunnable).start();
                    }
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    final EditText et = new EditText(this);
                    et.setInputType(InputType.TYPE_CLASS_TEXT);
                    et.setInputType(InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
                    et.setGravity(Gravity.CENTER_HORIZONTAL);
                    builder.setView(et);
                    builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            search = et.getText().toString().toUpperCase().trim();
                            Log.d(TAG, "onClick: String = " + search);
                            if(!search.trim().equals("")){
                                stockFind(search);
                            }
                            else
                            {
                                Toast.makeText(MainActivity.this, "Please Enter Stock Symbol", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                    builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {

                        }
                    });

                    builder.setMessage("Please enter a Stock Symbol:");
                    builder.setTitle("Stock Selection");
                    AlertDialog dialog = builder.create();
                    dialog.show();

                } else {
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setTitle("No Network Connection");
                    builder.setMessage("Stocks cannot Be Added Without a Network Connection");
                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    @Override
    public void onClick(View v) {

        @SuppressLint("SetJavaScriptEnabled")
        final int pos = recyclerstocks.getChildLayoutPosition(v);
        final Stock s = stockList.get(pos);
        if (s.getStockSymbol().trim().isEmpty()) {
            return;
        }
        String url = "https://www.marketwatch.com/investing/stock/" + s.getStockSymbol();
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(i);

    }


    @Override
    public boolean onLongClick(View v) {
        final int pos = recyclerstocks.getChildLayoutPosition(v);
        final Stock s = stockList.get(pos);
        // Simple Ok & Cancel dialog - no view used.
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setIcon(R.drawable.baseline_delete_black_18dp);

        builder.setPositiveButton("DELETE", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                databaseHandler.deleteStock(s);
                stockList.remove(pos);
                stockList = sortStocks(stockList);
                mAdapter.notifyDataSetChanged();
            }
        });
        builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {

            }
        });
        builder.setMessage("Delete Stock Symbol " + s.getStockSymbol());
        builder.setTitle("Delete Stock");
        AlertDialog dialog = builder.create();
        dialog.show();
        return false;
    }


    public void downloadFailed() {
        stockList.clear();
        mAdapter.notifyDataSetChanged();
    }

}