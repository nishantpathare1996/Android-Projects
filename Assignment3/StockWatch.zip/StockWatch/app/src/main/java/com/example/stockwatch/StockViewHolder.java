package com.example.stockwatch;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

public class StockViewHolder extends RecyclerView.ViewHolder {

    TextView stocksymbol, companyname, price, pricechange, percentchange;
    ImageView icon;

    StockViewHolder(View view) {
        super(view);
        stocksymbol = view.findViewById(R.id.stocksymbol);
        companyname = view.findViewById(R.id.companyname);
        price = view.findViewById(R.id.price);
        pricechange = view.findViewById(R.id.pricechange);
        percentchange = view.findViewById(R.id.percentchange);
        icon = view.findViewById(R.id.icon);
    }
}
