package com.example.stockwatch;

import android.net.Uri;
import android.util.Log;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;

public class NameRunnable implements Runnable {

    private static final String TAG = "NameRunnable";
    private MainActivity mainActivity;
    private static final String DATA_URL = "https://api.iextrading.com/1.0/ref-data/symbols";

    NameRunnable(MainActivity mainActivity) {this.mainActivity = mainActivity;}

    @Override
    public void run() {
            Uri dataUri = Uri.parse(DATA_URL);
            String urlToUse = dataUri.toString();
            Log.d(TAG, "run: " + urlToUse);

            StringBuilder sb = new StringBuilder();

            try {
                URL url = new URL(urlToUse);

                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.connect();

                if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
                    Log.d(TAG, "run: HTTP ResponseCode NOT OK: " + conn.getResponseCode());
                    handleResults(null);
                    return;
                }

                InputStream is = conn.getInputStream();
                BufferedReader reader = new BufferedReader((new InputStreamReader(is)));

                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line).append('\n');
                }

                Log.d(TAG, "run: " + sb.toString());

            } catch (Exception e) {
                Log.e(TAG, "run: ", e);
                handleResults(null);
                return;
            }

            handleResults(sb.toString());
    }

    private void handleResults(String s) {

        if (s == null) {
            Log.d(TAG, "handleResults: Failure in data download");
            mainActivity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    mainActivity.downloadFailed();
                }
            });
            return;
        }

        HashMap<String, String> stockList = parseJSON(s);
        mainActivity.updateData(stockList);
    }

    private HashMap<String,String> parseJSON(String s)
    {
        HashMap<String,String> hashMap = new HashMap<>();
        try
        {
            JSONArray jsonArray = new JSONArray(s);
            for (int i = 0; i < jsonArray.length(); i++)
            {
                JSONObject jStock = (JSONObject) jsonArray.get(i);
                String symbol = jStock.getString("symbol");
                String name = jStock.getString("name");
                hashMap.put(symbol,name);
            }
            return hashMap;
        }
        catch (Exception e)
        {
            Log.d(TAG, "parseJSON: bp:" + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }
}
