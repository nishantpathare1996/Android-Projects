package com.example.stockwatch;

import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.Locale;

public class StockAdapter extends RecyclerView.Adapter<StockViewHolder> {

    private static final String TAG = "StockAdapter";
    private List<Stock> stockList;
    private MainActivity mainAct;

    StockAdapter(List<Stock> stckList, MainActivity ma) {
        this.stockList = stckList;
        mainAct = ma;
    }

    @NonNull
    @Override
    public StockViewHolder onCreateViewHolder(@NonNull final ViewGroup parent, int viewType) {
        Log.d(TAG, "onCreateViewHolder: MAKING NEW");
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.stock_entry, parent, false);
        itemView.setOnClickListener(mainAct);
        itemView.setOnLongClickListener(mainAct);

        return new StockViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull StockViewHolder holder, int position) {
        Stock stock = stockList.get(position);
        holder.stocksymbol.setText(stock.getStockSymbol());
        holder.companyname.setText(stock.getCompanyName());
        holder.price.setText(String.format("$ %s", stock.getPrice()));;
        holder.pricechange.setText(String.format("%s", stock.getPriceChange()));
        holder.percentchange.setText(String.format("(%s %%)", stock.getChangePercentage()));


        int COLOR_CODE = stock.getCOLOR_CODE();

        switch (COLOR_CODE)
        {
            case 1: // Positive
                holder.stocksymbol.setTextColor(Color.parseColor("#0f9d58"));
                holder.companyname.setTextColor(Color.parseColor("#0f9d58"));
                holder.price.setTextColor(Color.parseColor("#0f9d58"));
                holder.pricechange.setTextColor(Color.parseColor("#0f9d58"));
                holder.percentchange.setTextColor(Color.parseColor("#0f9d58"));
                holder.icon.setBackgroundResource(R.drawable.ic_up_arrow);
                break;
            case 2: // Negative
                holder.stocksymbol.setTextColor(Color.parseColor("#db4437"));
                holder.companyname.setTextColor(Color.parseColor("#db4437"));
                holder.price.setTextColor(Color.parseColor("#db4437"));
                holder.pricechange.setTextColor(Color.parseColor("#db4437"));
                holder.percentchange.setTextColor(Color.parseColor("#db4437"));
                holder.icon.setBackgroundResource(R.drawable.ic_down_arrow);
                break;
            case 3:
                holder.stocksymbol.setTextColor(Color.parseColor("#FFFFFF"));
                holder.companyname.setTextColor(Color.parseColor("#FFFFFF"));
                holder.price.setTextColor(Color.parseColor("#FFFFFF"));
                holder.pricechange.setTextColor(Color.parseColor("#FFFFFF"));
                holder.percentchange.setTextColor(Color.parseColor("#FFFFFF"));
                holder.icon.setBackgroundResource(R.drawable.ic_neutral);
                break;
            default: // Neutral
                holder.stocksymbol.setTextColor(Color.parseColor("#656565"));
                holder.companyname.setTextColor(Color.parseColor("#656565"));
                holder.price.setTextColor(Color.parseColor("#656565"));
                holder.pricechange.setTextColor(Color.parseColor("#656565"));
                holder.percentchange.setTextColor(Color.parseColor("#656565"));
                holder.icon.setBackgroundResource(R.drawable.ic_neutral);
                break;
        }


    }

    @Override
    public int getItemCount() {
        return stockList.size();
    }

}

