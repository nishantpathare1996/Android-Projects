package com.example.stockwatch;

import android.net.Uri;
import android.util.Log;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

public class StockRunnable implements Runnable {

    private static final String TAG = "StockRunnable";
    private MainActivity mainActivity;
    // Sign up to get your API Key at:  https://iexcloud.io/cloud-login#/register
    private static final String yourAPIKey = "pk_27b8047e8983423e81f2b106b7a035b3";
    double changePercentage = 0.00;
    double latestPrice = 0.00;
    double priceChange = 0.00;

    StockRunnable(MainActivity mainActivity) {
        this.mainActivity = mainActivity;
    }

    @Override
    public void run() {
        ArrayList<Stock> stocksArrayList = mainActivity.getStocksArrayList();
        final ArrayList<Stock> tempList = new ArrayList<>();

        for (Stock temp : stocksArrayList) {
            String DATA_URL = "https://cloud.iexapis.com/stable/stock/" + temp.getStockSymbol() + "/quote?token=" + yourAPIKey;
            String data = getStockData(DATA_URL);
            Stock stock = parseJSON(data.toString());
            tempList.add(stock);
        }
        mainActivity.updateStockData(tempList);
    }

    private String getStockData(String URL){
        Uri dataUri = Uri.parse(URL);
        String urlToUse = dataUri.toString();
        Log.d(TAG, "run: " + urlToUse);

        StringBuilder sb = new StringBuilder();

        try {
            URL url = new URL(urlToUse);

            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.connect();

            InputStream is = conn.getInputStream();
            BufferedReader reader = new BufferedReader((new InputStreamReader(is)));

            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append('\n');
            }

            Log.d(TAG, "run: " + sb.toString());

        } catch (Exception e) {
            Log.e(TAG, "run: ", e);
            return null;
        }
        return sb.toString();

    }
    private String getSymbolfromAPI(String s)
    {
        String symbol = "";
        try
        {
            JSONObject jStock = new JSONObject(s);
            symbol = jStock.getString("symbol");
        }
        catch (Exception e)
        {
            Log.d(TAG, "ERROR| getSymbolfromAPI| bp:" + e.getMessage());
            e.printStackTrace();
        }

        return symbol;
    }

    private String getCompanyNamefromAPI(String s)
    {
        String companyName = "";
        try
        {
            JSONObject jStock = new JSONObject(s);
            companyName = jStock.getString("companyName");
        }
        catch (Exception e)
        {
            Log.d(TAG, "ERROR| getCompanyNamefromAPI| bp:" + e.getMessage());
            e.printStackTrace();
        }

        return companyName;
    }

    private double getLatestPricefromAPI(String s)
    {
        double latestPrice = 0.00;
        String tlatestPrice ;
        try
        {
            JSONObject jStock = new JSONObject(s);
            tlatestPrice = jStock.getString("latestPrice");
            latestPrice = Math.round(Double.parseDouble(tlatestPrice)*100.00)/100.00;
        }
        catch (Exception e)
        {
            Log.d(TAG, "ERROR| getLatestPricefromAPI| bp:" + e.getMessage());
            e.printStackTrace();
        }

        return latestPrice;
    }

    private double getChangefromAPI(String s)
    {
        double change = 0.00;
        String tChange;
        try
        {
            JSONObject jStock = new JSONObject(s);
            tChange = jStock.getString("change");
            change = Math.round(Double.parseDouble(tChange)*100.00)/100.00;
        }
        catch (Exception e)
        {
            Log.d(TAG, "ERROR| getChangefromAPI| bp:" + e.getMessage());
            e.printStackTrace();
        }

        return change;
    }

    private double getChangePercentfromAPI(String s)
    {
        double changePercent = 0.00;
        String tChangePercent;
        try
        {
            JSONObject jStock = new JSONObject(s);
            tChangePercent = jStock.getString("changePercent");
            changePercent = Math.round(Double.parseDouble(tChangePercent)*10000.00)/100.00;
        }
        catch (Exception e)
        {
            Log.d(TAG, "ERROR| getChangePercentfromAPI| bp:" + e.getMessage());
            e.printStackTrace();
        }

        return changePercent;
    }

    private Stock parseJSON(String s)
    {
        String symbol , companyName;
        double latestPrice , change , changePercent;

        symbol = getSymbolfromAPI(s);
        companyName = getCompanyNamefromAPI(s);
        latestPrice = getLatestPricefromAPI(s);
        change = getChangefromAPI(s);
        changePercent = getChangePercentfromAPI(s);
        Log.d(TAG, "parseJSON: bp: companyName: "+companyName + " latestPrice: "+ latestPrice + " change: "+change );

        return new Stock(symbol,companyName,latestPrice,change,changePercent);
    }

}
