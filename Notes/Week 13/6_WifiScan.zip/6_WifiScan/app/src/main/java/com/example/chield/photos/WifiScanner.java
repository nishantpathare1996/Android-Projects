package com.example.chield.photos;

import android.widget.Toast;

import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

public class WifiScanner implements Runnable {

    private MainActivity mainActivity;

    public WifiScanner(MainActivity mainActivity) {
        this.mainActivity = mainActivity;
    }

    @Override
    public void run() {

        if (!mainActivity.getWifiManager().isWifiEnabled()) {
            mainActivity.getWifiManager().setWifiEnabled(true);
            MainActivity.turnedItOn = true;
        }

        mainActivity.setBusy();

        boolean b = mainActivity.getWifiManager().startScan();
        if (!b) {
            mainActivity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(mainActivity, "TOO SOON", Toast.LENGTH_SHORT).show();
                    ((SwipeRefreshLayout) mainActivity.findViewById(R.id.sr_layout)).setRefreshing(false);
                }
            });
        }

    }
}
