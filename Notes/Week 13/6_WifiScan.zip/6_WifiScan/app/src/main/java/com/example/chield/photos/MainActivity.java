package com.example.chield.photos;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.appcompat.app.AppCompatActivity;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;


public class MainActivity extends AppCompatActivity {

    private WifiScanReceiver wifiReciever = new WifiScanReceiver();
    public static boolean turnedItOn = false;
    private WifiManager wifiManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ((TextView) findViewById(R.id.textView6)).setMovementMethod(new ScrollingMovementMethod());

        final SwipeRefreshLayout srl = findViewById(R.id.sr_layout);
        srl.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                srl.setRefreshing(false);
                new Thread(new WifiScanner(MainActivity.this)).start();
            }
        });
        wifiManager = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);

        new Thread(new WifiScanner(this)).start();

    }

    public void setBusy() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                ((SwipeRefreshLayout) findViewById(R.id.sr_layout)).setRefreshing(true);
            }
        });
    }


    public WifiManager getWifiManager() {
        return wifiManager;
    }

    @Override
    protected void onPause() {
        unregisterReceiver(wifiReciever);
        if (turnedItOn)
            wifiManager.setWifiEnabled(false);
        super.onPause();
    }

    @Override
    protected void onStop() {
        if (turnedItOn)
            wifiManager.setWifiEnabled(false);
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        if (turnedItOn)
            wifiManager.setWifiEnabled(false);
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        registerReceiver(wifiReciever, new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));
        super.onResume();
    }


    class WifiScanReceiver extends BroadcastReceiver {

        private static final String TAG = "WifiScanReceiver";

        public void onReceive(Context c, Intent intent) {

            ((SwipeRefreshLayout) findViewById(R.id.sr_layout)).setRefreshing(false);
            ((TextView) findViewById(R.id.timeText)).setText(new Date().toString());

            List<ScanResult> wifiList;
            wifiList = wifiManager.getScanResults();

            ArrayList<SortableScanSet> sorted = new ArrayList<>();
            for (ScanResult s : wifiList) {
                sorted.add(new SortableScanSet(s, calculateDistance(s.level, s.frequency)));
            }
            Collections.sort(sorted);

            SortableScanSet best = sorted.remove(0);
            ((TextView) findViewById(R.id.bestText)).setText(best.toString());

            StringBuilder sb = new StringBuilder();

            for (SortableScanSet s : sorted) {
                if (calculateDistance(s.scanResult.level, s.scanResult.frequency) >= 10.0)
                    break;
                sb.append(String.format("%s%n", s));
            }

            ((TextView) findViewById(R.id.textView6)).setText(sb.toString());
            ((TextView) findViewById(R.id.textView6)).scrollTo(0, 0);


            Log.d(TAG, "onReceive: END");

            unregisterReceiver(wifiReciever);
            registerReceiver(wifiReciever, new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));

        }


        public double calculateDistance(double signalLevelInDb, double freqInMHz) {
            double exp = (27.55 - (20 * Math.log10(freqInMHz)) + Math.abs(signalLevelInDb)) / 20.0;
            return Math.pow(10.0, exp);
        }


        public class SortableScanSet implements Comparable<SortableScanSet> {

            private ScanResult scanResult;
            private double distance;

            public SortableScanSet(ScanResult sr, double d) {
                scanResult = sr;
                distance = d;
            }

            @Override
            public int compareTo(@NonNull SortableScanSet o) {
                double diff = distance - o.distance;
                if (diff < 0)
                    return -1;
                else if (diff > 0)
                    return 1;
                else
                    return 0;
            }


            public int convertFrequencyToChannel(int freq) {
                if (freq >= 2412 && freq <= 2484) {
                    return (freq - 2412) / 5 + 1;
                } else if (freq >= 5170 && freq <= 5825) {
                    return (freq - 5170) / 5 + 34;
                } else {
                    return -1;
                }
            }

            @NonNull
            public String toString() {

                if (scanResult.SSID.isEmpty())
                    scanResult.SSID = "<Hidden SSID>";
                String freq = "5G";
                if (scanResult.frequency / 1000 == 2)
                    freq = "2.4G";

                String value =
                        String.format(Locale.getDefault(),
                                "%4.1f m  %s%n", calculateDistance(scanResult.level, scanResult.frequency), scanResult.SSID);
                value += String.format(Locale.getDefault(),"        BSSID: %s%n", scanResult.BSSID);
                value += String.format(Locale.getDefault(),"        Signal Strength: %s dB%n", scanResult.level);
                value += String.format(Locale.getDefault(),"        Channel: %d (%s)%n", convertFrequencyToChannel(scanResult.frequency), freq);

                return value;
            }

        }
    }


}
