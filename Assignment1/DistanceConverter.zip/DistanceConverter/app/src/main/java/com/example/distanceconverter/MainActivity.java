package com.example.distanceconverter;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.renderscript.Sampler;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    EditText tobeconvertededittext;
    TextView textview1, textview2, convertedtextview, historytextview, conversiontextview, multiLineScroll;
    RadioButton milestokm, kmtomiles;
    Button convertbutton, clearbutton;
    private float result=0;
    private String finalresult;

    private static DecimalFormat df = new DecimalFormat("0.0");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tobeconvertededittext = findViewById(R.id.tobeconvertededittext);

        conversiontextview = findViewById(R.id.conversiontextview);
        textview1 = findViewById(R.id.textview1);
        textview2 = findViewById(R.id.textview2);
        convertedtextview=findViewById(R.id.convertedtextview);
        historytextview = findViewById(R.id.historytextview);
        multiLineScroll = findViewById(R.id.multiLineScroll);

        milestokm = findViewById(R.id.milestokm);
        kmtomiles = findViewById(R.id.kmtomiles);

        convertbutton = findViewById(R.id.convertbutton);
        clearbutton = findViewById(R.id.clearbutton);

        multiLineScroll.setMovementMethod(new ScrollingMovementMethod());

    }

    public void buttonClicked(View v) {

        String newText = tobeconvertededittext.getText().toString();
        if (newText.isEmpty()) {
            tobeconvertededittext.setError("Required!");
            Toast.makeText(this, "Please Enter a Value", Toast.LENGTH_SHORT).show();
        }
        else{
            Float convertofloat = Float.parseFloat(newText);
            if(convertofloat > Float.MAX_VALUE){
                tobeconvertededittext.setError("Enter a Valid Number");
                Toast.makeText(this, "Please Enter a Valid Number", Toast.LENGTH_SHORT).show();
            }
            else{
                if(milestokm.isChecked()){
                    result = (float) (convertofloat * (1.60934));
                    finalresult = String.format("%.1f", result);
                }
                else if(kmtomiles.isChecked()){
                    result = (float) (convertofloat * (0.621371));
                    finalresult = String.format("%.1f", result);
                }

                String historyText = multiLineScroll.getText().toString();
                if(milestokm.isChecked()) {
                    multiLineScroll.setText(String.format("%s Mi ==> %s Km\n%s", newText, finalresult, historyText));
                }
                else if(kmtomiles.isChecked()){
                    multiLineScroll.setText(String.format("%s Km ==> %s Mi\n%s", newText, finalresult, historyText));
                }
                tobeconvertededittext.setText("");
                convertedtextview.setText(finalresult);

            }

        }

    }

    public void radioClicked(View v) {
        String message = "";
        String message1="Kilometers Value";

        if(v.getId() == R.id.kmtomiles){
            message1 = "Miles Value:";
        }
        else{
            message1 = "Kilometers Value:";
        }
        switch (v.getId()) {
            case R.id.milestokm:
                message += "Miles Value:";
                tobeconvertededittext.setHint("Enter Miles");
                break;
            case R.id.kmtomiles:
                message += "Kilometers Value:";
                tobeconvertededittext.setHint("Enter Kilometers");
                break;
        }
        textview1.setText(message);
        textview2.setText(message1);
    }

    public void clearButtonClicked(View v){
        multiLineScroll.setText("");
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {

        outState.putString("HISTORY", multiLineScroll.getText().toString());
        outState.putString("VALUE", finalresult);
        outState.putString("TextView1",textview1.getText().toString());
        outState.putString("TextView2",textview2.getText().toString());
        outState.putString("HINT",tobeconvertededittext.getHint().toString());

        // Call super last
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        // Call super first
        super.onRestoreInstanceState(savedInstanceState);

        multiLineScroll.setText(savedInstanceState.getString("HISTORY"));
        finalresult = savedInstanceState.getString("VALUE");
        convertedtextview.setText(finalresult);
        textview1.setText(savedInstanceState.getString("TextView1"));
        textview2.setText(savedInstanceState.getString("TextView2"));
        tobeconvertededittext.setHint(savedInstanceState.getString("HINT"));
    }
}